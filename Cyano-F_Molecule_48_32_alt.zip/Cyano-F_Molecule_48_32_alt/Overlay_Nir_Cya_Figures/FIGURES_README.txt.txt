
Cysteine 145 is highlighted in bright red.  This is where the 
sulfur reaction with the cyano takes place, with Nirmatrelvir.  
The distance between CYS 145 S and Molecule S is approximately 
the same in both molecules' binding modes.  A little bit less 
in the Cyano-F-Mol 48:32 than Nirmatrelvir.  I didn't show the 
side-chains, but if you open up the mol2 file and select show atoms 
then the image with side-chains will appear.  I calculated 
these distances and average distances over the 1st binding mode poses.) 
