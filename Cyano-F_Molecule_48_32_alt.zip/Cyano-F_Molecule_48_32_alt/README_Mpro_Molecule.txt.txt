Gordon Chalmers 
8/30/22

The directory has 6 types of files: 

-- 2 word documents - 

1) A general explanation of a potential SARS-Cov-2 Mpro inhibitor.
2) A detailed molecular binding analysis of Cyano-F_Molecule_48:32' to the site.  
   Both compare/contrast with Nirmatrelvir, the Mpro active ingredient in Pfizer's Paxlovid drug.

-- 4 .mol2 files - 
1) Mpro x-ray structure 7SI9 protonated and used in modeling
2) Cyano-F_Molecule_48:32' in its computationally modeled highest binding epitope, score 86.03
3) 2 epitopes of Nirmatrelvir computationally modeled and bound to Mpro
   These are the 2 highest scoring poses - described in detail in 
     Computational molecular modeling of Paxlovid binding, G. Chalmers, 
     10.26434/chemrxiv-2022-vfn6t, in review at the Euro. J. of Med. Chem.
   	score 72.64 
   	score 70.23 

-- 4 .png figures of Mpro/Cyano_F_Molecule_48:32'

-- Overlay_Nir_Cya directory with additional pictures of Cyano_F_Molecule (pink) overlayed with Nirmatrelvir (blue)

-- Chemdraw of Cyano-F_Molecule_48:32' and labeled

-- Score distributions of 20000 docking runs with both the Mpro (3CL) protease 
      and the enzyme CYP 3A4

-- SIB swissadme output in .csv format (recommended to use it online) 

-- this READ_ME_Mpro_Molecule file

-- 2 relevant preprints, in review


-- to use the chemdraw colored .cdx file in chemdraw, change the extension .changemetext, .changeme to .cdx

-- detailed amino acid interaction analysis is not here, such as philic/phobic or charged/uncharged, but 
    the .mol2 files have it from those epitope configurations

